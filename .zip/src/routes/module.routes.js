const express = require('express');
const { createModule } = require('../controllers/moduleController');
const { protect } = require('../middleware/auth'); // Middleware to verify JWT

const router = express.Router();

// Create new module
router.post('/', protect, createModule);

module.exports = router;
