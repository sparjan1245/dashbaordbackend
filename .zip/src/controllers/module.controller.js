const Module = require('../models/Module.model');

// @desc    Create new module
// @route   POST /api/modules
// @access  Private (attach company/user from auth middleware)
exports.createModule = async (req, res) => {
  try {
    const { module, description } = req.body;
    const company = req.user.company;
    const createdBy = req.user.id;

    if (!module) {
      return res.status(400).json({ success: false, message: 'Module name is required' });
    }

    const newModule = await Module.create({
      module,
      description,
      company,
      createdBy
    });

    res.status(201).json({
      success: true,
      data: newModule
    });
  } catch (error) {
    console.error('Create module error:', error);
    res.status(500).json({ success: false, message: 'Server Error' });
  }
};
