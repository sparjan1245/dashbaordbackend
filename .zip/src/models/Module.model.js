const mongoose = require('mongoose');

const ModuleSchema = new mongoose.Schema({
  module: { type: String, required: true, unique: true },
  description: { type: String },
  fields: { type: Array, default: [] },
  company: { type: mongoose.Schema.Types.ObjectId, ref: 'Company', required: true },
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Module', ModuleSchema);
